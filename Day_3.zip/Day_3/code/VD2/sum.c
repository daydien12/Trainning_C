#include "sum.h"

int SUM(int a, int b)
{
    printf("\na + b = %d\n", (a+b));
}