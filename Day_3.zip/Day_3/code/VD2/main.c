
#include "sum.h"
int main()
{
    SUM(10, 20);
    printf("Makefile project   !!!\n");
    
}