#ifndef __SUM_H__
#define __SUM_H__

#include <stdio.h>
int SUM(int a, int b);

#endif