#include "file1.h"
#include <stdio.h>

void Func_1(void)
{
    printf("Function 1! \n");
}