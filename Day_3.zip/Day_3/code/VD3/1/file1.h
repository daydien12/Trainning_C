#ifndef __F1_H__
#define __F1_H__


void Func_1(void);

#endif