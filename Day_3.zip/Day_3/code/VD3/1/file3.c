#include "file3.h"
#include <stdio.h>

void Func_3(void)
{
    printf("Function 3! \n");
}