#ifndef __F2_H__
#define __F2_H__


void Func_2(void);

#endif