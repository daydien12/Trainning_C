#include "file4.h"
#include <stdio.h>

void Func_4(void)
{
    printf("Function 4! \n");
}