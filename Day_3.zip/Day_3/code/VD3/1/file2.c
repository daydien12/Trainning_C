#include "file2.h"
#include <stdio.h>

void Func_2(void)
{
    printf("Function 2! \n");
}