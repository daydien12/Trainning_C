#include "file1.h"
#include "file2.h"
#include "file3.h"
#include "file4.h"

int main()
{
    Func_1();
    Func_2();
    Func_3();
    Func_4();
}